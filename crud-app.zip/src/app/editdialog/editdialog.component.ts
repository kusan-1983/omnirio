import { Component, OnInit, Inject } from '@angular/core';
import { CrudService } from '../services/crud.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-editdialog',
  templateUrl: './editdialog.component.html',
  styleUrls: ['./editdialog.component.scss']
})
export class EditdialogComponent implements OnInit {
  editData: EditData;
  id: number;
  constructor( private crudService: CrudService, public dialogRef: MatDialogRef<EditdialogComponent>,
    // tslint:disable-next-line:align
    @Inject(MAT_DIALOG_DATA) public data: EditData) {}

    ngOnInit(): void {
      console.log(this.data);
      this.id = this.data.id;
      this.editData = this.data;
    }

  onNoClick(): void {
    this.dialogRef.close();
  }

  submit(v): void {
    console.log(v.value);
    this.crudService.postData(v.value, this.id).subscribe(data => {
      console.log(data);
      this.dialogRef.close();
    });
  }
}

export interface EditData {
  id: number;
  name: string;
  email: string;
  gender: string;
  status: string;
  created_at: string;
}