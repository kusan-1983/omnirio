import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CrudService {
  url = 'http://dummy.restapiexample.com/api/v1/employees';
  headers = new HttpHeaders()
  .set('content-type', 'application/json')
  .set('Access-Control-Allow-Origin', '*').set('Accept', 'application/json').set('Authorization', 'Bearer d12dd75666bd82ba2b5d3374e8e6b6c549f3bc4e15863f3696995c2011566488');

  constructor(private http: HttpClient) { }

  getTableData(): Observable<any>{
    return this.http.get('https://gorest.co.in/public-api/users');
  }
  deleteByid(id): any{
    return this.http.delete('https://gorest.co.in/public-api/users/' + id, { headers : this.headers } );
  }

  postData(uData){
    return this.http.post('https://gorest.co.in/public-api/users', uData, { headers : this.headers });
  }
  putData(uData, id){
    return this.http.put('https://gorest.co.in/public-api/users/' + id, uData, { headers : this.headers });
  }
}
