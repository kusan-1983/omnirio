import { Component, OnInit, ViewChild, AfterViewInit, Inject } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { EditdialogComponent } from '../editdialog/editdialog.component';
import { CrudService } from '../services/crud.service';
import {MatDialog} from '@angular/material/dialog';

@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.scss']
})
export class DatatableComponent implements OnInit {
   data: any;
   animal: string;
   name: string;

  constructor(private crudService: CrudService, public dialog: MatDialog) { }
  displayedColumns: string[] = ['id', 'name', 'email', 'gender', 'status', 'action'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);


  ngOnInit(): void {
    //this.dataSource.paginator = this.paginator;
    this.crudService.getTableData().subscribe(data => {
      console.log(data);
      this.dataSource  = data.data;
    });

  }

  deleteRow(id: any): void{
    console.log(id);
    this.crudService.deleteByid(id).subscribe(data => {
      console.log(data);
      this.crudService.getTableData().subscribe(datas => {
        this.dataSource = new MatTableDataSource<PeriodicElement>(datas.data);
      });
    });
  }


  openDialog(element): void {
    const dialogRef = this.dialog.open(EditdialogComponent, {
      width: '450px',
      data: element
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      this.animal = result;
      this.crudService.getTableData().subscribe(data => {
        console.log(data);
        this.dataSource  = data.data;
      });
    });
  }

}


export interface PeriodicElement {
  id: number;
  name: string;
  email: string;
  gender: string;
  status: string;
  created_at: string;
}

const ELEMENT_DATA: PeriodicElement[] = [];
